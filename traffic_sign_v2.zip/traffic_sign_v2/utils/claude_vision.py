"""
============================================================
  utils/claude_vision.py
  Claude AI Vision API integration
============================================================
"""

import cv2, base64, json, urllib.request, urllib.error
import numpy as np

PROMPT = """
You are a traffic sign recognition AI. Analyze the image.

Respond ONLY with valid JSON. No markdown, no explanation.

If a sign is found:
{
  "found": true,
  "name": "sign name",
  "category": "Mandatory | Prohibitory | Warning | Regulatory | Informational",
  "shape": "Octagon | Circle | Triangle | Rectangle | Diamond | Other",
  "primary_color": "main colors",
  "required_action": "what driver must do",
  "confidence": <0-100>,
  "critical": <true/false>,
  "description": "2-3 sentences about this sign.",
  "alert_message": "urgent message if critical, else empty string"
}

If NO sign:
{"found": false, "description": "what is visible instead"}
"""

class ClaudeVisionAnalyzer:
    def __init__(self, api_key):
        self.api_key = api_key

    def analyze(self, frame):
        _, buf = cv2.imencode('.jpg', frame, [cv2.IMWRITE_JPEG_QUALITY, 85])
        b64 = base64.b64encode(buf).decode()

        payload = json.dumps({
            "model": "claude-opus-4-5",
            "max_tokens": 800,
            "messages": [{
                "role": "user",
                "content": [
                    {"type": "image", "source": {"type": "base64", "media_type": "image/jpeg", "data": b64}},
                    {"type": "text", "text": PROMPT}
                ]
            }]
        }).encode()

        req = urllib.request.Request(
            "https://api.anthropic.com/v1/messages",
            data=payload,
            headers={
                "Content-Type": "application/json",
                "x-api-key": self.api_key,
                "anthropic-version": "2023-06-01"
            },
            method="POST"
        )
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                data = json.loads(resp.read())
            raw = "".join(b.get("text","") for b in data.get("content",[]))
            raw = raw.strip().replace("```json","").replace("```","").strip()
            return json.loads(raw)
        except Exception as e:
            return {"found": False, "error": True, "description": str(e)}
