# Traffic Sign Recognition System v2
### 20 Sign Classes | Trained ML Model | Python + OpenCV + scikit-learn

---

## Quick Start (3 Steps)

```bash
# Step 1 — Install packages
pip install opencv-python numpy scikit-learn pillow

# Step 2 — Generate training dataset (300 images × 20 signs = 6000 images)
python training/generate_dataset.py

# Step 3 — Train the ML model (~2-3 minutes)
python training/train_model.py

# Step 4 — Run the detector
python main.py
```

---

## Project Structure

```
traffic_sign_v2/
├── main.py                        ← Run this to start
├── detector.py                    ← Camera loop + ML + AI pipeline
├── requirements.txt
├── CHATGPT_HELP_GUIDE.md          ← Troubleshooting prompts
│
├── training/
│   ├── generate_dataset.py        ← Creates 6000 synthetic training images
│   └── train_model.py             ← Trains Random Forest, saves model
│
├── models/
│   ├── sign_info.py               ← All 20 sign definitions
│   ├── sign_model.pkl             ← Saved after training (auto-created)
│   └── labels.pkl                 ← Class names (auto-created)
│
├── utils/
│   └── claude_vision.py           ← Claude AI Vision API
│
├── dataset/
│   └── raw/<CLASS>/img_XXXX.jpg  ← Generated training images
│
└── screenshots/                   ← Saved detections (press S)
```

---

## 20 Sign Classes

| # | Sign | Category | Critical |
|---|------|----------|----------|
| 1 | STOP | Mandatory | ✅ |
| 2 | NO_ENTRY | Prohibitory | ✅ |
| 3 | SPEED_LIMIT | Regulatory | — |
| 4 | NO_OVERTAKING | Prohibitory | — |
| 5 | NO_PARKING | Prohibitory | — |
| 6 | ONE_WAY | Mandatory | — |
| 7 | TURN_LEFT | Mandatory | — |
| 8 | TURN_RIGHT | Mandatory | — |
| 9 | SCHOOL_AHEAD | Warning | ✅ |
| 10 | CURVE_AHEAD | Warning | — |
| 11 | ROAD_WORK_AHEAD | Warning | — |
| 12 | NARROW_ROAD | Warning | — |
| 13 | ROUNDABOUT_AHEAD | Mandatory | — |
| 14 | SPEED_BREAKER | Warning | — |
| 15 | HOSPITAL | Informational | — |
| 16 | PARKING | Informational | — |
| 17 | PETROL_PUMP | Informational | — |
| 18 | BUS_STOP | Informational | — |
| 19 | REST_AREA | Informational | — |
| 20 | TOILET | Informational | — |

---

## Controls

| Key | Action |
|-----|--------|
| `SPACE` | Analyze current frame (Claude AI or ML) |
| `A` | Toggle auto-detect every 5 seconds |
| `S` | Save screenshot |
| `C` | Clear AI result panel |
| `Q` / `ESC` | Quit |

---

## How the ML Pipeline Works

```
Camera Frame
    │
    ▼
HSV Color Mask ──── Finds red/blue/yellow regions
    │
    ▼
Contour Detection ── Finds boundaries of colored regions
    │
    ▼
Crop Region (ROI) ── Extract each candidate sign area
    │
    ▼
Feature Extraction:
  • HOG (shape edges)          — 144 features
  • HSV Histogram (color)      — 48 features
  • Color Ratios               — 6 features
  • LBP Texture                — 256 features
  • Hu Moments (geometry)      — 7 features
  Total: ~461 features
    │
    ▼
Random Forest (150 trees) ──── Votes → Predicted Label + Confidence
    │
    ▼
Display box + label on screen
```

---

## Improving Accuracy

To get better results, increase samples per class in `generate_dataset.py`:

```python
SAMPLES_PER_CLASS = 500   # Increase from 300 to 500+
```

Then retrain:
```bash
python training/generate_dataset.py
python training/train_model.py
```

Expected accuracy with 300 samples/class: **~70-85%**
Expected accuracy with 500 samples/class: **~80-90%**
