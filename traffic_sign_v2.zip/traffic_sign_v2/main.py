"""
============================================================
  main.py — Entry Point

  USAGE:
    Step 1 — Generate training dataset:
      python training/generate_dataset.py

    Step 2 — Train the model:
      python training/train_model.py

    Step 3 — Run the detector:
      python main.py

  CONTROLS:
    SPACE  — Capture & analyze (Claude AI or ML fallback)
    A      — Toggle auto-detect every 5 seconds
    S      — Save screenshot
    C      — Clear current AI result
    Q/ESC  — Quit
============================================================
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from detector import TrafficSignDetector

def main():
    print("=" * 60)
    print("   TRAFFIC SIGN RECOGNITION SYSTEM  v2.0")
    print("   20 Sign Classes | ML + AI Pipeline")
    print("=" * 60)
    print()
    print("  Controls:")
    print("    SPACE  — Analyze current frame")
    print("    A      — Toggle auto-detect (every 5s)")
    print("    S      — Save screenshot")
    print("    C      — Clear result panel")
    print("    Q/ESC  — Quit")
    print()

    app = TrafficSignDetector()
    app.run()

if __name__ == "__main__":
    main()
