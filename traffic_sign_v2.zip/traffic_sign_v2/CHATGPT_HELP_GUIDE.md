# CHATGPT TROUBLESHOOTING GUIDE
## Traffic Sign Recognition System — Python + ML + OpenCV
---

Use the prompts below **word for word** when you face problems.
Paste the prompt into ChatGPT, then paste your error after it.

---

## PROMPT 1 — When a package install fails

```
I am building a Python Traffic Sign Recognition project.
I tried to install packages using:

  pip install -r requirements.txt

But I got this error:

[PASTE YOUR ERROR HERE]

My Python version is: [paste output of: python --version]
My OS is: [Windows / macOS / Ubuntu]

The packages I need are: opencv-python, numpy, scikit-learn, pillow

Please give me the exact commands to fix this.
```

---

## PROMPT 2 — When generate_dataset.py fails

```
I am building a Traffic Sign Recognition system in Python.
I ran this command:

  python training/generate_dataset.py

And got this error:

[PASTE YOUR FULL ERROR HERE]

Here is the top of my generate_dataset.py file:

[PASTE first 30 lines of generate_dataset.py]

The project folder structure is:
  traffic_sign_v2/
    main.py
    detector.py
    training/
      generate_dataset.py
      train_model.py
    models/
      sign_info.py
    utils/
      claude_vision.py

Please explain what caused the error and give me the exact fix.
```

---

## PROMPT 3 — When train_model.py gives low accuracy

```
I am training a Machine Learning model (Random Forest) to detect
traffic signs using Python and scikit-learn.

I ran:
  python training/train_model.py

And the output said:
  OVERALL ACCURACY: [PASTE % HERE]

The training report was:
[PASTE the full classification report table here]

My dataset has:
  - [X] classes (signs)
  - [Y] images per class
  - Image size: 64x64 pixels

The feature extractor uses: HOG, HSV histograms, LBP texture, Hu moments.
The model is: RandomForestClassifier with 150 trees.

What is causing low accuracy and how do I improve it?
Should I increase dataset size, change model parameters, or change features?
```

---

## PROMPT 4 — When the camera does not open

```
I am running a Python OpenCV project for traffic sign detection.
I ran:

  python main.py

And I see this error:
  [ERROR] Cannot open camera.

or the OpenCV window opens but shows a black screen.

My code opens the camera like this:
  cap = cv2.VideoCapture(0)

I am on: [Windows / macOS / Ubuntu]
Python version: [paste python --version]
OpenCV version: [paste: python -c "import cv2; print(cv2.__version__)"]

Please tell me:
1. How to check if my camera is working
2. How to change the camera index (0, 1, 2...)
3. How to fix permission issues on my OS
```

---

## PROMPT 5 — When signs are detected wrong / low confidence

```
I have a trained Traffic Sign Recognition model in Python.
It uses OpenCV for camera input and a scikit-learn Random Forest.

The problem is:
  - [STOP] sign is detected correctly most of the time
  - [TURN RIGHT / NO PARKING / etc.] signs are NOT being detected
  - Confidence scores are low (below 50%)

My setup:
  - 20 sign classes
  - Training dataset: 300 synthetic images per class
  - Feature vector: HOG + HSV histogram + LBP + Hu moments (461 dimensions)
  - Model: RandomForestClassifier(n_estimators=150)
  - Image size: 64x64

What are the top reasons why some signs are not detected?
How do I:
  1. Generate better training data
  2. Improve features for similar-looking signs (e.g. all blue rectangles)
  3. Tune the Random Forest hyperparameters
  4. Lower the confidence threshold safely
```

---

## PROMPT 6 — When Claude API key does not work

```
I am using the Anthropic Claude API in a Python project for traffic sign analysis.
I entered my API key when prompted, but I see this error:

[PASTE ERROR HERE]

My code calls the API like this:
  - URL: https://api.anthropic.com/v1/messages
  - Model: claude-opus-4-5
  - It sends a base64 JPEG image and a text prompt
  - Uses urllib.request (no extra libraries)

My API key format: sk-ant-...

Please help me:
1. Check if the API key is valid
2. Fix any authentication errors
3. Handle rate limits or quota exceeded errors
```

---

## PROMPT 7 — When model.pkl file is not found

```
I am running a Python traffic sign detector.
I ran:  python main.py

And got:
  [ERROR] Model not found at models/sign_model.pkl

I have already run:
  python training/generate_dataset.py   ← this worked
  python training/train_model.py        ← [paste if it worked or gave error]

My folder structure is:
  traffic_sign_v2/
    main.py
    models/
      sign_info.py
      [sign_model.pkl is MISSING here]
    training/
      generate_dataset.py
      train_model.py

Where is the model file supposed to be saved?
Why is it not being created?
What command do I run from which folder?
```

---

## PROMPT 8 — For the Mentor Presentation (Explaining ML concepts)

```
I am a student presenting a Traffic Sign Recognition project to my mentor.
The project uses Python with these technologies:

  COMPUTER VISION (OpenCV):
    - HSV color masking to find red/blue/yellow sign regions
    - Canny edge detection
    - Contour detection and polygon approximation for shapes

  MACHINE LEARNING (scikit-learn):
    - Feature extraction: HOG + HSV histograms + LBP + Hu moments
    - Model: Random Forest Classifier (150 decision trees)
    - Training: 300 synthetic images per class, 20 classes = 6000 images
    - Evaluation: 80/20 train-test split, classification report

  AI VISION (Anthropic Claude API):
    - Sends base64 JPEG to Claude's multimodal model
    - Gets structured JSON with sign name, category, action, confidence
    - Runs in a background thread to avoid blocking the camera

Please give me clear, simple explanations (suitable for a college-level mentor) for:
1. Why HSV is better than RGB for color-based detection
2. How HOG features capture sign shape information
3. Why Random Forest is good for this task (vs a single decision tree)
4. What the confusion matrix and classification report tell us
5. Why threading is needed for the API call
6. How synthetic data generation works and its limitations
```

---

## GENERAL TIPS FOR USING CHATGPT ON THIS PROJECT

1. **Always paste the full error** — not just the last line.
   Copy from the terminal: `Ctrl+A` then `Ctrl+C` to get everything.

2. **Tell ChatGPT your OS** — Windows, macOS, or Linux/Ubuntu matters for
   camera and package issues.

3. **Share the relevant code block** — paste the function or file section
   that is causing the problem.

4. **Ask for step-by-step commands** — ChatGPT will give you exact terminal
   commands to fix the issue.

5. **If one fix doesn't work** — tell ChatGPT: "That didn't work. I got this
   new error: [paste new error]" and continue the conversation.
