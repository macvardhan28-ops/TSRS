"""
============================================================
  training/train_model.py

  MODEL TRAINING PIPELINE
  ────────────────────────
  This script:
    1. Loads all images from dataset/raw/
    2. Extracts rich feature vectors from each image
    3. Trains a Random Forest classifier
    4. Evaluates accuracy with a test split
    5. Saves the trained model to models/sign_model.pkl

  HOW IT WORKS — MACHINE LEARNING PIPELINE:
  ──────────────────────────────────────────
  Image → Feature Extractor → Feature Vector → ML Model → Label

  Feature Extraction uses:
    a) HOG (Histogram of Oriented Gradients)
       - Divides image into cells, computes gradient directions
       - Captures shape information (edges, corners)
       - Classic CV technique, very effective for rigid shapes

    b) Color Histograms (HSV)
       - How much red, blue, yellow in the image
       - Saturation and value distributions

    c) LBP (Local Binary Pattern)
       - Captures texture at every pixel
       - Good for distinguishing sign backgrounds

  Model:
    Random Forest (100 trees, max_depth=12)
    + StandardScaler for feature normalization

  Run with:
    python training/train_model.py
============================================================
"""

import cv2
import numpy as np
import os
import pickle
import time
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
from sklearn.pipeline import Pipeline


IMG_SIZE = 64           # Must match generate_dataset.py
DATASET_DIR = "dataset/raw"
MODEL_PATH = "models/sign_model.pkl"
LABELS_PATH = "models/labels.pkl"


# ─────────────────────────────────────────────────────────
#  FEATURE EXTRACTOR
#  Converts a 64×64 BGR image → 1D feature vector
# ─────────────────────────────────────────────────────────

class RichFeatureExtractor:
    """
    Extracts a comprehensive feature vector from each image.
    
    Total features: ~600 dimensions
      - HOG features:        ~144
      - HSV histograms:       48
      - Color ratios:          6
      - LBP texture:         256
      - Spatial moments:      10
    """

    def extract(self, img: np.ndarray) -> np.ndarray:
        """
        Convert image to feature vector.
        
        Args:
            img: BGR image, any size (will be resized internally)
        
        Returns:
            1D numpy float32 array
        """
        if img is None or img.size == 0:
            return np.zeros(600, dtype=np.float32)

        img = cv2.resize(img, (IMG_SIZE, IMG_SIZE))
        features = []

        # ── (A) HOG Features ──────────────────────────────
        # HOG = Histogram of Oriented Gradients
        # Works by:
        #   1. Compute gradient (edge direction) at each pixel
        #   2. Divide image into 8×8 cells
        #   3. Build histogram of gradient directions per cell
        #   4. Normalize across 2×2 blocks of cells
        # Result: a vector that encodes WHERE edges are and their direction
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        winSize = (IMG_SIZE, IMG_SIZE)
        blockSize = (16, 16)
        blockStride = (8, 8)
        cellSize = (8, 8)
        nbins = 9
        hog = cv2.HOGDescriptor(winSize, blockSize, blockStride, cellSize, nbins)
        hog_feat = hog.compute(gray).flatten()
        features.append(hog_feat[:144])  # Use first 144 values

        # ── (B) HSV Color Histograms ──────────────────────
        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
        h_hist = cv2.calcHist([hsv], [0], None, [16], [0, 180]).flatten()
        s_hist = cv2.calcHist([hsv], [1], None, [16], [0, 256]).flatten()
        v_hist = cv2.calcHist([hsv], [2], None, [16], [0, 256]).flatten()
        # Normalize each histogram
        h_hist /= (h_hist.sum() + 1e-6)
        s_hist /= (s_hist.sum() + 1e-6)
        v_hist /= (v_hist.sum() + 1e-6)
        features.extend([h_hist, s_hist, v_hist])

        # ── (C) Color Ratios ──────────────────────────────
        # What fraction of pixels fall in each color range?
        r1 = cv2.inRange(hsv, np.array([0, 80, 60]),   np.array([10, 255, 255]))
        r2 = cv2.inRange(hsv, np.array([160, 80, 60]), np.array([180, 255, 255]))
        red_ratio   = float((r1.sum() + r2.sum())) / (IMG_SIZE * IMG_SIZE * 255 * 2)
        blue_ratio  = float(cv2.inRange(hsv, np.array([100, 60, 60]), np.array([135, 255, 255])).sum()) / (IMG_SIZE * IMG_SIZE * 255)
        yellow_ratio= float(cv2.inRange(hsv, np.array([18, 60, 60]),  np.array([35, 255, 255])).sum())  / (IMG_SIZE * IMG_SIZE * 255)
        orange_ratio= float(cv2.inRange(hsv, np.array([10, 80, 80]),  np.array([20, 255, 255])).sum())  / (IMG_SIZE * IMG_SIZE * 255)
        white_ratio = float(cv2.inRange(hsv, np.array([0, 0, 200]),   np.array([180, 30, 255])).sum())  / (IMG_SIZE * IMG_SIZE * 255)
        black_ratio = float(cv2.inRange(hsv, np.array([0, 0, 0]),     np.array([180, 255, 50])).sum())  / (IMG_SIZE * IMG_SIZE * 255)
        features.append(np.array([red_ratio, blue_ratio, yellow_ratio, orange_ratio, white_ratio, black_ratio]))

        # ── (D) LBP Texture ───────────────────────────────
        # Local Binary Pattern: at each pixel, compare with 8 neighbors.
        # If neighbor > center pixel → 1, else → 0.
        # 8 comparisons → 8-bit number → texture descriptor.
        lbp = self._compute_lbp(gray)
        lbp_hist, _ = np.histogram(lbp.ravel(), bins=256, range=(0, 256))
        lbp_hist = lbp_hist.astype(np.float32) / (lbp_hist.sum() + 1e-6)
        features.append(lbp_hist)

        # ── (E) Spatial Moments (Shape geometry) ──────────
        moments = cv2.moments(gray)
        hu = cv2.HuMoments(moments).flatten()
        # Log-scale (Hu moments span many orders of magnitude)
        hu_log = -np.sign(hu) * np.log10(np.abs(hu) + 1e-10)
        features.append(hu_log)

        return np.concatenate(features).astype(np.float32)

    def _compute_lbp(self, gray: np.ndarray) -> np.ndarray:
        """Simple LBP implementation using OpenCV."""
        # Use the 3×3 neighborhood
        h, w = gray.shape
        lbp = np.zeros((h, w), dtype=np.uint8)
        neighbors = [(-1,-1),(-1,0),(-1,1),(0,1),(1,1),(1,0),(1,-1),(0,-1)]
        for bit, (dy, dx) in enumerate(neighbors):
            shifted = np.roll(np.roll(gray, dy, axis=0), dx, axis=1)
            lbp |= ((gray >= shifted).astype(np.uint8) << bit)
        return lbp


# ─────────────────────────────────────────────────────────
#  DATASET LOADER
# ─────────────────────────────────────────────────────────

def load_dataset(dataset_dir: str, extractor: RichFeatureExtractor):
    """
    Load all images from dataset/raw/<CLASS>/*.jpg
    and convert them to feature vectors.
    
    Returns:
        X: (N, feature_dim) array
        y: (N,) array of class indices
        labels: list of class names
    """
    X, y = [], []
    labels = sorted(os.listdir(dataset_dir))
    labels = [l for l in labels if os.path.isdir(os.path.join(dataset_dir, l))]

    print(f"  Found {len(labels)} classes in {dataset_dir}")
    print()

    for class_idx, class_name in enumerate(labels):
        class_dir = os.path.join(dataset_dir, class_name)
        files = [f for f in os.listdir(class_dir) if f.endswith('.jpg')]

        count = 0
        for fname in files:
            fpath = os.path.join(class_dir, fname)
            img = cv2.imread(fpath)
            if img is None:
                continue
            feat = extractor.extract(img)
            X.append(feat)
            y.append(class_idx)
            count += 1

        print(f"  [{class_idx+1:2d}/{len(labels)}] {class_name:25s} — {count} images loaded")

    return np.array(X, dtype=np.float32), np.array(y, dtype=np.int32), labels


# ─────────────────────────────────────────────────────────
#  TRAINING MAIN
# ─────────────────────────────────────────────────────────

def train():
    print("=" * 60)
    print("  TRAFFIC SIGN MODEL TRAINING")
    print("=" * 60)
    print()

    extractor = RichFeatureExtractor()

    # ── Step 1: Load Dataset ──────────────────────────────
    print("[STEP 1] Loading dataset...")
    t0 = time.time()
    X, y, labels = load_dataset(DATASET_DIR, extractor)
    print(f"\n  Dataset loaded in {time.time()-t0:.1f}s")
    print(f"  Total samples: {len(X)}")
    print(f"  Feature vector size: {X.shape[1]}")
    print()

    if len(X) == 0:
        print("[ERROR] No images found! Run generate_dataset.py first.")
        return

    # ── Step 2: Train/Test Split ──────────────────────────
    print("[STEP 2] Splitting into train (80%) / test (20%)...")
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    print(f"  Train: {len(X_train)} samples")
    print(f"  Test:  {len(X_test)} samples")
    print()

    # ── Step 3: Build Pipeline ────────────────────────────
    # Pipeline = StandardScaler + RandomForest
    # StandardScaler: normalizes features to mean=0, std=1
    #   (prevents features with large values from dominating)
    print("[STEP 3] Building model pipeline...")
    print("  StandardScaler → RandomForestClassifier(100 trees)")
    model = Pipeline([
        ("scaler", StandardScaler()),
        ("clf", RandomForestClassifier(
            n_estimators=150,       # 150 decision trees
            max_depth=None,         # Grow until pure leaves
            min_samples_split=4,
            min_samples_leaf=2,
            max_features="sqrt",    # sqrt(n_features) per split
            random_state=42,
            n_jobs=-1,              # Use all CPU cores
            verbose=0
        ))
    ])
    print()

    # ── Step 4: Train ─────────────────────────────────────
    print("[STEP 4] Training model... (may take 1-3 minutes)")
    t0 = time.time()
    model.fit(X_train, y_train)
    elapsed = time.time() - t0
    print(f"  Training complete in {elapsed:.1f}s")
    print()

    # ── Step 5: Evaluate ──────────────────────────────────
    print("[STEP 5] Evaluating on test set...")
    y_pred = model.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    print(f"\n  OVERALL ACCURACY: {acc:.1%}")
    print()
    print("  Per-class report:")
    print("  " + "-" * 55)
    report = classification_report(y_test, y_pred, target_names=labels, digits=2)
    for line in report.split('\n'):
        print("  " + line)

    # ── Step 6: Save ──────────────────────────────────────
    print()
    print("[STEP 6] Saving trained model...")
    os.makedirs("models", exist_ok=True)

    # Save model + extractor together in a bundle
    bundle = {
        "model": model,
        "extractor": extractor,
        "labels": labels,
        "accuracy": acc,
    }
    with open(MODEL_PATH, "wb") as f:
        pickle.dump(bundle, f)

    with open(LABELS_PATH, "wb") as f:
        pickle.dump(labels, f)

    print(f"  Model saved → {os.path.abspath(MODEL_PATH)}")
    print(f"  Labels saved → {os.path.abspath(LABELS_PATH)}")
    print()
    print("=" * 60)
    print(f"  TRAINING COMPLETE — Accuracy: {acc:.1%}")
    print("  Next step: run   python main.py")
    print("=" * 60)


if __name__ == "__main__":
    train()
