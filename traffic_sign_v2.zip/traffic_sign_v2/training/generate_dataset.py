"""
============================================================
  training/generate_dataset.py

  SYNTHETIC DATASET GENERATOR
  ─────────────────────────────
  Generates realistic synthetic training images for all
  20 traffic sign classes. Each sign is drawn programmatically
  with:
    - Correct shape (octagon, circle, triangle, rectangle)
    - Correct colors (red, blue, yellow, white, black)
    - Correct symbol / text
    - Random augmentations:
        • Brightness variation (day/night conditions)
        • Gaussian noise (camera sensor noise)
        • Blur (motion/focus blur)
        • Rotation (slight angle)
        • Scale variation (distance from camera)
        • Color jitter (different lighting temperatures)
        • Background clutter (random patches)

  Output:
    dataset/raw/<CLASS_NAME>/img_0001.jpg  ...  img_0300.jpg

  Run with:
    python training/generate_dataset.py
============================================================
"""

import cv2
import numpy as np
import os
import math

# ─────────────────────────────────────────────────────────
#  SIGN DEFINITIONS
#  Each entry defines visual properties for drawing
# ─────────────────────────────────────────────────────────
SIGNS = {
    "STOP": {
        "shape": "octagon",
        "bg_color": (0, 0, 200),        # Red (BGR)
        "border_color": (255, 255, 255),
        "text": "STOP",
        "text_color": (255, 255, 255),
        "symbol": None,
    },
    "NO_ENTRY": {
        "shape": "circle",
        "bg_color": (0, 0, 200),
        "border_color": (255, 255, 255),
        "text": None,
        "text_color": (255, 255, 255),
        "symbol": "no_entry_bar",
    },
    "SPEED_LIMIT": {
        "shape": "circle",
        "bg_color": (255, 255, 255),
        "border_color": (0, 0, 200),
        "text": "60",
        "text_color": (0, 0, 0),
        "symbol": None,
    },
    "NO_OVERTAKING": {
        "shape": "circle",
        "bg_color": (255, 255, 255),
        "border_color": (0, 0, 200),
        "text": None,
        "text_color": (0, 0, 0),
        "symbol": "no_overtaking",
    },
    "NO_PARKING": {
        "shape": "circle",
        "bg_color": (255, 255, 255),
        "border_color": (0, 0, 200),
        "text": "P",
        "text_color": (0, 0, 200),
        "symbol": "cross_diagonal",
    },
    "ONE_WAY": {
        "shape": "rectangle",
        "bg_color": (200, 0, 0),        # Blue
        "border_color": (255, 255, 255),
        "text": "ONE WAY",
        "text_color": (255, 255, 255),
        "symbol": "arrow_right",
    },
    "TURN_LEFT": {
        "shape": "circle",
        "bg_color": (200, 0, 0),        # Blue
        "border_color": (255, 255, 255),
        "text": None,
        "text_color": (255, 255, 255),
        "symbol": "arrow_left",
    },
    "TURN_RIGHT": {
        "shape": "circle",
        "bg_color": (200, 0, 0),        # Blue
        "border_color": (255, 255, 255),
        "text": None,
        "text_color": (255, 255, 255),
        "symbol": "arrow_right_curve",
    },
    "SCHOOL_AHEAD": {
        "shape": "triangle",
        "bg_color": (0, 200, 200),      # Yellow
        "border_color": (0, 0, 0),
        "text": "SCHOOL",
        "text_color": (0, 0, 0),
        "symbol": None,
    },
    "CURVE_AHEAD": {
        "shape": "triangle",
        "bg_color": (0, 200, 200),      # Yellow
        "border_color": (0, 0, 0),
        "text": None,
        "text_color": (0, 0, 0),
        "symbol": "curve",
    },
    "ROAD_WORK_AHEAD": {
        "shape": "triangle",
        "bg_color": (0, 165, 255),      # Orange
        "border_color": (0, 0, 0),
        "text": None,
        "text_color": (0, 0, 0),
        "symbol": "shovel",
    },
    "NARROW_ROAD": {
        "shape": "triangle",
        "bg_color": (0, 200, 200),      # Yellow
        "border_color": (0, 0, 0),
        "text": None,
        "text_color": (0, 0, 0),
        "symbol": "narrow",
    },
    "ROUNDABOUT_AHEAD": {
        "shape": "circle",
        "bg_color": (200, 0, 0),        # Blue
        "border_color": (255, 255, 255),
        "text": None,
        "text_color": (255, 255, 255),
        "symbol": "roundabout",
    },
    "SPEED_BREAKER": {
        "shape": "triangle",
        "bg_color": (0, 200, 200),      # Yellow
        "border_color": (0, 0, 0),
        "text": "BUMP",
        "text_color": (0, 0, 0),
        "symbol": None,
    },
    "HOSPITAL": {
        "shape": "rectangle",
        "bg_color": (200, 0, 0),        # Blue
        "border_color": (255, 255, 255),
        "text": "H",
        "text_color": (255, 255, 255),
        "symbol": None,
    },
    "PARKING": {
        "shape": "rectangle",
        "bg_color": (200, 0, 0),        # Blue
        "border_color": (255, 255, 255),
        "text": "P",
        "text_color": (255, 255, 255),
        "symbol": None,
    },
    "PETROL_PUMP": {
        "shape": "rectangle",
        "bg_color": (200, 0, 0),        # Blue
        "border_color": (255, 255, 255),
        "text": "FUEL",
        "text_color": (255, 255, 255),
        "symbol": None,
    },
    "BUS_STOP": {
        "shape": "rectangle",
        "bg_color": (200, 0, 0),        # Blue
        "border_color": (255, 255, 255),
        "text": "BUS",
        "text_color": (255, 255, 255),
        "symbol": None,
    },
    "REST_AREA": {
        "shape": "rectangle",
        "bg_color": (200, 0, 0),        # Blue
        "border_color": (255, 255, 255),
        "text": "REST",
        "text_color": (255, 255, 255),
        "symbol": None,
    },
    "TOILET": {
        "shape": "rectangle",
        "bg_color": (200, 0, 0),        # Blue
        "border_color": (255, 255, 255),
        "text": "WC",
        "text_color": (255, 255, 255),
        "symbol": None,
    },
}

IMG_SIZE = 64           # Final image size (64x64 pixels)
SAMPLES_PER_CLASS = 300 # How many images per sign


# ─────────────────────────────────────────────────────────
#  SHAPE DRAWING FUNCTIONS
# ─────────────────────────────────────────────────────────

def draw_octagon(canvas, cx, cy, r, color, border, border_w=4):
    """Draw a stop-sign octagon."""
    pts = []
    for i in range(8):
        angle = math.pi / 8 + i * math.pi / 4
        pts.append([int(cx + r * math.cos(angle)), int(cy + r * math.sin(angle))])
    pts = np.array(pts, dtype=np.int32)
    cv2.fillPoly(canvas, [pts], color)
    cv2.polylines(canvas, [pts], True, border, border_w)
    return canvas

def draw_circle_sign(canvas, cx, cy, r, color, border, border_w=5):
    cv2.circle(canvas, (cx, cy), r, color, -1)
    cv2.circle(canvas, (cx, cy), r, border, border_w)
    return canvas

def draw_triangle_sign(canvas, cx, cy, r, color, border, border_w=4, inverted=False):
    if inverted:
        pts = np.array([
            [cx, int(cy + r)],
            [int(cx - r * 0.87), int(cy - r * 0.5)],
            [int(cx + r * 0.87), int(cy - r * 0.5)],
        ], dtype=np.int32)
    else:
        pts = np.array([
            [cx, int(cy - r)],
            [int(cx - r * 0.87), int(cy + r * 0.5)],
            [int(cx + r * 0.87), int(cy + r * 0.5)],
        ], dtype=np.int32)
    cv2.fillPoly(canvas, [pts], color)
    cv2.polylines(canvas, [pts], True, border, border_w)
    return canvas

def draw_rect_sign(canvas, cx, cy, r, color, border, border_w=4):
    x1, y1 = cx - r, int(cy - r * 0.6)
    x2, y2 = cx + r, int(cy + r * 0.6)
    cv2.rectangle(canvas, (x1, y1), (x2, y2), color, -1)
    cv2.rectangle(canvas, (x1, y1), (x2, y2), border, border_w)
    return canvas


# ─────────────────────────────────────────────────────────
#  SYMBOL DRAWING FUNCTIONS
# ─────────────────────────────────────────────────────────

def draw_symbol(canvas, symbol, cx, cy, r, color):
    """Draw inner symbol for signs that don't use text."""
    t = max(2, r // 10)

    if symbol == "no_entry_bar":
        bh = max(4, r // 3)
        cv2.rectangle(canvas, (cx - r + 14, cy - bh), (cx + r - 14, cy + bh), color, -1)

    elif symbol == "arrow_right":
        pts = np.array([[cx - r//2, cy - r//4],
                        [cx + r//5, cy - r//4],
                        [cx + r//5, cy - r//2],
                        [cx + r//2, cy],
                        [cx + r//5, cy + r//2],
                        [cx + r//5, cy + r//4],
                        [cx - r//2, cy + r//4]], dtype=np.int32)
        cv2.fillPoly(canvas, [pts], color)

    elif symbol == "arrow_left":
        pts = np.array([[cx + r//2, cy - r//4],
                        [cx - r//5, cy - r//4],
                        [cx - r//5, cy - r//2],
                        [cx - r//2, cy],
                        [cx - r//5, cy + r//2],
                        [cx - r//5, cy + r//4],
                        [cx + r//2, cy + r//4]], dtype=np.int32)
        cv2.fillPoly(canvas, [pts], color)

    elif symbol == "arrow_right_curve":
        # Straight part
        cv2.line(canvas, (cx - r//2, cy), (cx, cy), color, max(4, r//5))
        # Arrowhead (right-upward curve)
        cv2.line(canvas, (cx, cy), (cx + r//3, cy - r//3), color, max(4, r//5))
        # Arrow tip
        pts = np.array([[cx + r//3, cy - r//3],
                        [cx + r//3 - 8, cy - r//3 + 14],
                        [cx + r//3 + 8, cy - r//3 + 6]], dtype=np.int32)
        cv2.fillPoly(canvas, [pts], color)

    elif symbol == "cross_diagonal":
        cv2.line(canvas, (cx - r + 10, cy - r + 10), (cx + r - 10, cy + r - 10), (0, 0, 200), max(4, r//5))
        cv2.line(canvas, (cx + r - 10, cy - r + 10), (cx - r + 10, cy + r - 10), (0, 0, 200), max(4, r//5))

    elif symbol == "no_overtaking":
        # Two circles side by side
        cv2.circle(canvas, (cx - r//4, cy), r//3, (100, 100, 100), -1)
        cv2.circle(canvas, (cx + r//4, cy), r//3, (0, 0, 200), -1)
        cv2.line(canvas, (cx - r + 10, cy - r + 10), (cx + r - 10, cy + r - 10), (0, 0, 200), max(3, r//8))

    elif symbol == "roundabout":
        cv2.circle(canvas, (cx, cy), r // 2, color, max(4, r//6))
        # Arrows on circle
        for angle in [0, 120, 240]:
            rad = math.radians(angle)
            ax = int(cx + (r//2) * math.cos(rad))
            ay = int(cy + (r//2) * math.sin(rad))
            cv2.circle(canvas, (ax, ay), max(3, r//10), color, -1)

    elif symbol == "curve":
        pts = np.array([[cx - r//3, cy + r//3],
                        [cx - r//3, cy - r//4],
                        [cx, cy - r//2],
                        [cx + r//3, cy - r//4],
                        [cx + r//3, cy + r//3]], dtype=np.int32)
        cv2.polylines(canvas, [pts], False, color, max(4, r//6))

    elif symbol == "shovel":
        cv2.line(canvas, (cx, cy - r//2), (cx, cy + r//2), color, max(4, r//7))
        cv2.ellipse(canvas, (cx, cy - r//4), (r//4, r//4), 0, 0, 180, color, max(3, r//8))

    elif symbol == "narrow":
        # Two vertical bars with arrows pointing inward
        left_x, right_x = cx - r//2, cx + r//2
        cv2.line(canvas, (left_x, cy - r//3), (left_x, cy + r//3), color, max(3, r//8))
        cv2.line(canvas, (right_x, cy - r//3), (right_x, cy + r//3), color, max(3, r//8))
        # Arrows pointing to center
        cv2.arrowedLine(canvas, (left_x - 2, cy), (cx - 6, cy), color, max(2, r//10), tipLength=0.4)
        cv2.arrowedLine(canvas, (right_x + 2, cy), (cx + 6, cy), color, max(2, r//10), tipLength=0.4)


# ─────────────────────────────────────────────────────────
#  AUGMENTATION FUNCTIONS
#  Makes model robust to real-world conditions
# ─────────────────────────────────────────────────────────

def random_background(size):
    """Generate random background (road, sky, wall textures)."""
    bg_type = np.random.choice(["solid", "gradient", "noise", "road"])
    bg = np.zeros((size, size, 3), dtype=np.uint8)

    if bg_type == "solid":
        color = np.random.randint(30, 200, 3).tolist()
        bg[:] = color

    elif bg_type == "gradient":
        c1 = np.random.randint(20, 180, 3)
        c2 = np.random.randint(20, 180, 3)
        for i in range(size):
            t = i / size
            bg[i, :] = (c1 * (1 - t) + c2 * t).astype(np.uint8)

    elif bg_type == "noise":
        bg = np.random.randint(50, 180, (size, size, 3), dtype=np.uint8)

    elif bg_type == "road":
        bg[:] = [60, 60, 60]
        # Lane markings
        for y in range(0, size, 20):
            if np.random.rand() > 0.5:
                cv2.line(bg, (size // 2 - 2, y), (size // 2 - 2, y + 10), (200, 200, 200), 2)

    return bg

def augment(img):
    """Apply random augmentations to a sign image."""
    out = img.copy()

    # 1. Brightness jitter
    beta = np.random.randint(-60, 60)
    out = np.clip(out.astype(np.int16) + beta, 0, 255).astype(np.uint8)

    # 2. Gaussian noise
    if np.random.rand() > 0.4:
        noise = np.random.normal(0, np.random.uniform(3, 18), out.shape).astype(np.int16)
        out = np.clip(out.astype(np.int16) + noise, 0, 255).astype(np.uint8)

    # 3. Blur (focus / motion blur)
    if np.random.rand() > 0.5:
        k = np.random.choice([3, 5])
        out = cv2.GaussianBlur(out, (k, k), 0)

    # 4. Slight rotation
    if np.random.rand() > 0.3:
        angle = np.random.uniform(-18, 18)
        h, w = out.shape[:2]
        M = cv2.getRotationMatrix2D((w // 2, h // 2), angle, 1.0)
        out = cv2.warpAffine(out, M, (w, h), borderMode=cv2.BORDER_REFLECT)

    # 5. Scale (zoom in/out)
    if np.random.rand() > 0.4:
        scale = np.random.uniform(0.75, 1.2)
        h, w = out.shape[:2]
        new_w, new_h = int(w * scale), int(h * scale)
        resized = cv2.resize(out, (new_w, new_h))
        # Crop or pad back to original size
        canvas = np.zeros_like(out)
        oy = max(0, (new_h - h) // 2)
        ox = max(0, (new_w - w) // 2)
        cy_end = min(new_h, oy + h)
        cx_end = min(new_w, ox + w)
        dy = cy_end - oy
        dx = cx_end - ox
        canvas[:dy, :dx] = resized[oy:cy_end, ox:cx_end]
        out = canvas

    # 6. Horizontal flip (only for symmetric signs)
    if np.random.rand() > 0.7:
        out = cv2.flip(out, 1)

    # 7. Color jitter (warm/cool lighting)
    if np.random.rand() > 0.5:
        factor = np.random.uniform(0.85, 1.15, 3)
        out = np.clip(out * factor, 0, 255).astype(np.uint8)

    return out


# ─────────────────────────────────────────────────────────
#  MAIN SIGN RENDERER
# ─────────────────────────────────────────────────────────

def render_sign(sign_info, size=128):
    """
    Draw a traffic sign on a random background.
    
    Returns a square image with the sign centered.
    """
    canvas_size = int(size * np.random.uniform(1.3, 1.8))
    bg = random_background(canvas_size)
    canvas = bg.copy()

    cx, cy = canvas_size // 2, canvas_size // 2
    r = int(size * np.random.uniform(0.38, 0.48))

    shape = sign_info["shape"]
    color = sign_info["bg_color"]
    border = sign_info["border_color"]

    # Add slight color variation to make training data diverse
    color = tuple(np.clip(np.array(color) + np.random.randint(-20, 20, 3), 0, 255).tolist())

    # Draw the shape
    if shape == "octagon":
        draw_octagon(canvas, cx, cy, r, color, border)
    elif shape == "circle":
        draw_circle_sign(canvas, cx, cy, r, color, border)
    elif shape == "triangle":
        draw_triangle_sign(canvas, cx, cy, r, color, border)
    elif shape == "rectangle":
        draw_rect_sign(canvas, cx, cy, r, color, border)

    # Draw symbol if defined
    if sign_info["symbol"]:
        sym_color = sign_info["text_color"]
        draw_symbol(canvas, sign_info["symbol"], cx, cy, r, sym_color)

    # Draw text if defined
    if sign_info["text"]:
        text = sign_info["text"]
        txt_color = sign_info["text_color"]
        font = cv2.FONT_HERSHEY_SIMPLEX

        # Auto-scale font to fit inside sign
        for fs in [0.9, 0.7, 0.5, 0.4, 0.3]:
            tw, th = cv2.getTextSize(text, font, fs, 2)[0]
            if tw < r * 1.5 and th < r * 0.9:
                break

        tx = cx - tw // 2
        ty = cy + th // 2

        # Shadow for readability
        cv2.putText(canvas, text, (tx + 2, ty + 2), font, fs, (30, 30, 30), 3, cv2.LINE_AA)
        cv2.putText(canvas, text, (tx, ty), font, fs, txt_color, 2, cv2.LINE_AA)

    # Resize to target size
    final = cv2.resize(canvas, (size, size), interpolation=cv2.INTER_AREA)
    return final


# ─────────────────────────────────────────────────────────
#  DATASET GENERATION MAIN
# ─────────────────────────────────────────────────────────

def generate_dataset(output_dir="dataset/raw", samples=SAMPLES_PER_CLASS, size=IMG_SIZE):
    """Generate full dataset for all sign classes."""
    print("=" * 60)
    print("  SYNTHETIC DATASET GENERATOR")
    print(f"  {len(SIGNS)} classes × {samples} samples = {len(SIGNS)*samples} images")
    print(f"  Image size: {size}×{size} pixels")
    print("=" * 60)

    total = 0
    for class_name, sign_info in SIGNS.items():
        class_dir = os.path.join(output_dir, class_name)
        os.makedirs(class_dir, exist_ok=True)

        for i in range(samples):
            img = render_sign(sign_info, size=size)
            img = augment(img)
            fname = os.path.join(class_dir, f"img_{i:04d}.jpg")
            cv2.imwrite(fname, img, [cv2.IMWRITE_JPEG_QUALITY, 92])
            total += 1

        print(f"  [OK] {class_name:25s} — {samples} images saved → {class_dir}")

    print()
    print(f"  Done! {total} total images generated.")
    print(f"  Output: {os.path.abspath(output_dir)}")
    print()
    print("  Next step: run   python training/train_model.py")


if __name__ == "__main__":
    generate_dataset()
