"""
============================================================
  train.py

  YOLOV8 TRAINING SCRIPT
  ──────────────────────
  Trains YOLOv8s on the generated traffic sign dataset.

  What happens:
    1. Downloads YOLOv8s pretrained weights (yolov8s.pt)
       — pretrained on COCO dataset (80 common objects)
    2. Fine-tunes on our 20 traffic sign classes
       — this is called Transfer Learning
    3. Saves best model to runs/train/weights/best.pt

  Transfer Learning explained:
    Instead of training from scratch (needs millions of images),
    we start from a model already trained to detect objects.
    It already knows edges, shapes, textures. We just teach it
    our specific signs. Much faster, much more accurate.

  Run: python train.py
============================================================
"""

import os
import sys

def train():
    try:
        from ultralytics import YOLO
    except ImportError:
        print("[ERROR] ultralytics not installed.")
        print("  Run:  pip install ultralytics")
        sys.exit(1)

    script_dir = os.path.dirname(os.path.abspath(__file__))
    yaml_path  = os.path.join(script_dir, "dataset", "data.yaml")

    if not os.path.exists(yaml_path):
        print("[ERROR] Dataset not found.")
        print("  Run:  python generate_dataset.py   first")
        sys.exit(1)

    print("="*60)
    print("  YOLOV8 TRAINING — Traffic Sign Recognition")
    print("="*60)
    print()
    print("  Model:    YOLOv8s (small — fast + accurate)")
    print("  Method:   Transfer Learning from COCO weights")
    print("  Classes:  20 traffic sign types")
    print("  Epochs:   50")
    print()

    # Load YOLOv8s — downloads pretrained weights automatically
    model = YOLO("yolov8s.pt")

    # Train
    results = model.train(
        data    = yaml_path,
        epochs  = 50,           # training rounds (increase to 100 for better accuracy)
        imgsz   = 640,          # input image size
        batch   = 16,           # images per batch (reduce to 8 if you get memory errors)
        name    = "traffic_signs",
        project = os.path.join(script_dir, "runs"),
        patience= 15,           # stop early if no improvement for 15 epochs
        save    = True,
        plots   = True,         # save training graphs
        verbose = True,
        device  = "cpu",        # change to 0 if you have an NVIDIA GPU
    )

    best_path = os.path.join(script_dir, "runs", "traffic_signs", "weights", "best.pt")
    print()
    print("="*60)
    print("  TRAINING COMPLETE")
    print(f"  Best model saved → {best_path}")
    print()
    print("  Next step:  python detect.py")
    print("="*60)

if __name__ == "__main__":
    train()
