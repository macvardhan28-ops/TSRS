"""
============================================================
  detector.py

  REAL-TIME DETECTION ENGINE
  ───────────────────────────
  Loads the trained model from models/sign_model.pkl and
  runs live detection on the webcam feed.

  Two-stage pipeline:
    Stage 1 (every frame): OpenCV region detection → ML model
    Stage 2 (on demand):   Claude Vision AI deep analysis
============================================================
"""

import cv2
import numpy as np
import pickle
import os
import time
import threading
from models.sign_info import SIGN_DATABASE


MODEL_PATH = "models/sign_model.pkl"
CONF_THRESHOLD = 0.45       # Minimum ML confidence to show a detection


# ─────────────────────────────────────────────────────────
#  MODEL LOADER
# ─────────────────────────────────────────────────────────

def load_model():
    """Load trained model bundle from disk."""
    if not os.path.exists(MODEL_PATH):
        print()
        print("=" * 60)
        print("  MODEL NOT FOUND — TRAINING REQUIRED")
        print("=" * 60)
        print()
        print("  You need to run these two commands FIRST:")
        print()
        print("  Step 1:  python training/generate_dataset.py")
        print("  Step 2:  python training/train_model.py")
        print("  Step 3:  python main.py   (then run this again)")
        print()
        print("  Make sure you run all commands from inside the")
        print("  traffic_sign_v2 folder, for example:")
        print()
        print("  cd C:\\Users\\Student\\Downloads\\traffic_sign_v2\\traffic_sign_v2")
        print("  python training/generate_dataset.py")
        print()
        print("=" * 60)
        return None, None, None

    try:
        with open(MODEL_PATH, "rb") as f:
            bundle = pickle.load(f)

        model     = bundle["model"]
        extractor = bundle["extractor"]
        labels    = bundle["labels"]
        acc       = bundle.get("accuracy", 0)

        print(f"[MODEL] Loaded: {len(labels)} classes | Training accuracy: {acc:.1%}")
        return model, extractor, labels

    except Exception as e:
        print(f"[ERROR] Failed to load model: {e}")
        print("        The model file may be corrupted.")
        print("        Delete models/sign_model.pkl and retrain.")
        return None, None, None


# ─────────────────────────────────────────────────────────
#  REGION DETECTOR (OpenCV)
#  Finds candidate sign regions in a frame using color masks
# ─────────────────────────────────────────────────────────

class RegionDetector:
    """
    Uses HSV color masking to find sign-colored regions.
    Fast — runs every frame at full FPS.
    """

    def find_regions(self, frame: np.ndarray) -> list:
        """
        Returns list of (x, y, w, h, color_name) for candidate regions.
        """
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        regions = []

        color_masks = [
            # (mask, color_label)
            (cv2.bitwise_or(
                cv2.inRange(hsv, np.array([0, 80, 60]),   np.array([12, 255, 255])),
                cv2.inRange(hsv, np.array([158, 80, 60]), np.array([180, 255, 255]))
            ), "Red"),
            (cv2.inRange(hsv, np.array([100, 60, 60]), np.array([135, 255, 255])), "Blue"),
            (cv2.inRange(hsv, np.array([18, 60, 60]),  np.array([36, 255, 255])),  "Yellow"),
            (cv2.inRange(hsv, np.array([10, 80, 80]),  np.array([20, 255, 255])),  "Orange"),
        ]

        seen = set()
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (9, 9))

        for mask, color_name in color_masks:
            # Morphological clean-up: fill holes, remove noise
            mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
            mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)

            contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

            for cnt in contours:
                area = cv2.contourArea(cnt)
                if area < 1800:     # Too small to be a sign
                    continue

                x, y, w, h = cv2.boundingRect(cnt)
                aspect = w / (h + 1e-6)

                # Signs are roughly square-ish
                if not (0.35 < aspect < 2.8):
                    continue

                # Avoid duplicate overlapping boxes
                key = (x // 20, y // 20)
                if key in seen:
                    continue
                seen.add(key)

                regions.append((x, y, w, h, color_name))

        return regions


# ─────────────────────────────────────────────────────────
#  DISPLAY HELPERS
# ─────────────────────────────────────────────────────────

def put_text_shadow(img, text, x, y, scale, color, thickness=1):
    cv2.putText(img, text, (x+1, y+1), cv2.FONT_HERSHEY_SIMPLEX, scale, (0,0,0), thickness+1, cv2.LINE_AA)
    cv2.putText(img, text, (x, y), cv2.FONT_HERSHEY_SIMPLEX, scale, color, thickness, cv2.LINE_AA)

def draw_panel_bg(img, x1, y1, x2, y2, alpha=0.82):
    overlay = img.copy()
    cv2.rectangle(overlay, (x1, y1), (x2, y2), (18, 22, 30), -1)
    cv2.addWeighted(overlay, alpha, img, 1 - alpha, 0, img)

def confidence_color(conf):
    if conf >= 0.75: return (0, 200, 100)
    if conf >= 0.55: return (0, 165, 255)
    return (0, 80, 220)

def draw_scan_corners(img, color=(0, 229, 160)):
    h, w = img.shape[:2]
    m, s = 16, 28
    t = 2
    cv2.line(img, (m, m), (m+s, m), color, t)
    cv2.line(img, (m, m), (m, m+s), color, t)
    cv2.line(img, (w-m, m), (w-m-s, m), color, t)
    cv2.line(img, (w-m, m), (w-m, m+s), color, t)
    cv2.line(img, (m, h-m), (m+s, h-m), color, t)
    cv2.line(img, (m, h-m), (m, h-m-s), color, t)
    cv2.line(img, (w-m, h-m), (w-m-s, h-m), color, t)
    cv2.line(img, (w-m, h-m), (w-m, h-m-s), color, t)


# ─────────────────────────────────────────────────────────
#  MAIN DETECTOR CLASS
# ─────────────────────────────────────────────────────────

class TrafficSignDetector:

    def __init__(self):
        print("[INIT] Loading trained model...")
        self.model, self.extractor, self.labels = load_model()
        if self.model is None:
            return

        self.region_detector = RegionDetector()

        # App state
        self.ai_result = None
        self.scanning = False
        self.auto_mode = False
        self.auto_interval = 5.0
        self.last_auto = 0
        self.total = 0
        self.running = True
        self.show_scores = True
        self.last_ml_detections = []   # For persistent display

        # Claude Vision (optional)
        self.claude = None
        self._ask_api_key()

    def _ask_api_key(self):
        print()
        print("─" * 55)
        print("  ANTHROPIC API KEY (Optional — for deep AI analysis)")
        print("  Get yours: https://console.anthropic.com")
        print("─" * 55)
        key = input("  Enter key (or press Enter to skip): ").strip()
        if key.startswith("sk-ant"):
            try:
                from utils.claude_vision import ClaudeVisionAnalyzer
                self.claude = ClaudeVisionAnalyzer(key)
                print("  [OK] Claude Vision AI connected.")
            except Exception as e:
                print(f"  [WARN] Claude setup failed: {e}")
        else:
            print("  [INFO] Running in ML-only mode.")
        print()

    def _predict_region(self, roi) -> tuple:
        """Run ML model on a cropped region. Returns (label, confidence, all_scores)."""
        if roi is None or roi.size == 0:
            return None, 0.0, {}

        feat = self.extractor.extract(roi)
        proba = self.model.predict_proba([feat])[0]
        classes = self.model.classes_

        # classes are indices; map to label names
        sorted_idx = np.argsort(proba)[::-1]
        top_class = classes[sorted_idx[0]]
        top_label = self.labels[top_class]
        top_conf = proba[sorted_idx[0]]

        all_scores = {self.labels[classes[i]]: proba[i] for i in sorted_idx[:5]}
        return top_label, float(top_conf), all_scores

    def _ai_analyze(self, frame):
        """Run Claude Vision in background thread."""
        self.scanning = True

        def _run():
            try:
                if self.claude:
                    result = self.claude.analyze(frame)
                else:
                    # Fallback: ML on full frame
                    top_label, top_conf, _ = self._predict_region(frame)
                    info = SIGN_DATABASE.get(top_label, {})
                    result = {
                        "found": top_conf >= CONF_THRESHOLD,
                        "name": info.get("display_name", top_label),
                        "category": info.get("category", "Unknown"),
                        "shape": info.get("shape", "—"),
                        "primary_color": ", ".join(info.get("colors", [])),
                        "required_action": info.get("action", "—"),
                        "confidence": int(top_conf * 100),
                        "critical": info.get("critical", False),
                        "description": f"Detected by ML with {top_conf:.0%} confidence.",
                        "alert_message": info.get("alert", ""),
                    }

                self.ai_result = result
                if result.get("found"):
                    self.total += 1
                    print(f"[AI] {result.get('name')} — {result.get('confidence')}% confidence")
                else:
                    print(f"[AI] {result.get('description', 'No sign found')}")
            except Exception as e:
                print(f"[AI ERROR] {e}")
            finally:
                self.scanning = False

        threading.Thread(target=_run, daemon=True).start()

    def _draw_header(self, frame, fps):
        h, w = frame.shape[:2]
        draw_panel_bg(frame, 0, 0, w, 42)
        cv2.line(frame, (0, 42), (w, 42), (0, 229, 160), 1)
        put_text_shadow(frame, "TRAFFIC SIGN RECOGNITION", 12, 16, 0.45, (0, 229, 160), 1)
        put_text_shadow(frame, "ML + AI PIPELINE", 12, 33, 0.35, (100, 120, 130), 1)
        status = "SCANNING..." if self.scanning else "AUTO ON" if self.auto_mode else "LIVE"
        put_text_shadow(frame, status, w - 180, 20, 0.4, (255, 255, 255), 1)
        put_text_shadow(frame, f"FPS:{fps:.0f}  DET:{self.total}", w - 180, 36, 0.35, (100, 120, 130), 1)

    def _draw_ml_boxes(self, frame, regions):
        """Draw ML detection boxes on frame."""
        for (x, y, w, h, color_name, label, conf, _) in regions:
            if conf < CONF_THRESHOLD:
                continue
            box_color = confidence_color(conf)
            cv2.rectangle(frame, (x, y), (x+w, y+h), box_color, 2)

            info = SIGN_DATABASE.get(label, {})
            disp_name = info.get("display_name", label.replace("_", " "))

            # Label background
            label_text = f"{disp_name}"
            conf_text = f"{conf:.0%}"
            (lw, lh), _ = cv2.getTextSize(label_text, cv2.FONT_HERSHEY_SIMPLEX, 0.42, 1)
            draw_panel_bg(frame, x, y - 22, x + lw + 60, y, 0.9)
            put_text_shadow(frame, label_text, x + 4, y - 8, 0.42, box_color, 1)
            put_text_shadow(frame, conf_text, x + lw + 8, y - 8, 0.38, (0, 229, 160), 1)

    def _draw_ai_panel(self, frame):
        """Draw Claude AI result panel on the right."""
        if not self.ai_result:
            return
        r = self.ai_result
        h, w = frame.shape[:2]
        pw = 300
        px = w - pw - 10
        py = 52
        pad = 12

        draw_panel_bg(frame, px, py, px + pw, h - 38, 0.9)
        cv2.rectangle(frame, (px, py), (px+pw, h-38), (40,50,60), 1)
        y = py + 18

        if r.get("found"):
            name = r.get("name", "Unknown")
            put_text_shadow(frame, name.upper(), px+pad, y, 0.48, (255,255,255), 1)
            y += 20

            cat = r.get("category", "")
            cat_colors = {"Mandatory":(200,0,0),"Prohibitory":(0,0,220),"Warning":(0,165,255),
                         "Regulatory":(0,0,200),"Informational":(200,0,0)}
            cc = cat_colors.get(cat, (100,120,130))
            put_text_shadow(frame, cat, px+pad, y, 0.36, cc, 1)
            y += 18

            cv2.line(frame, (px+pad, y), (px+pw-pad, y), (50,60,70), 1)
            y += 12

            # Confidence bar
            conf = r.get("confidence", 0)
            put_text_shadow(frame, "CONFIDENCE", px+pad, y, 0.32, (100,120,130), 1)
            y += 14
            bar_w = pw - pad * 2
            cv2.rectangle(frame, (px+pad, y), (px+pad+bar_w, y+7), (40,50,60), -1)
            fill_w = int(bar_w * conf / 100)
            fill_c = (0,200,100) if conf >= 75 else (0,165,255) if conf >= 55 else (0,80,220)
            cv2.rectangle(frame, (px+pad, y), (px+pad+fill_w, y+7), fill_c, -1)
            put_text_shadow(frame, f"{conf}%", px+pad+bar_w-26, y+6, 0.35, (255,255,255), 1)
            y += 20

            cv2.line(frame, (px+pad, y), (px+pw-pad, y), (50,60,70), 1)
            y += 12

            # Details
            for key, val in [("SHAPE", r.get("shape","—")),
                             ("COLOR", r.get("primary_color","—")),
                             ("ACTION", r.get("required_action","—"))]:
                put_text_shadow(frame, key, px+pad, y, 0.3, (100,120,130), 1)
                val_str = str(val)[:30]
                put_text_shadow(frame, val_str, px+pad+66, y, 0.33, (200,210,220), 1)
                y += 16

            y += 4
            cv2.line(frame, (px+pad, y), (px+pw-pad, y), (50,60,70), 1)
            y += 12

            # Description
            put_text_shadow(frame, "AI ANALYSIS", px+pad, y, 0.3, (100,120,130), 1)
            y += 14
            desc = r.get("description", "")
            words = desc.split()
            line = ""
            for word in words:
                test = line + (" " if line else "") + word
                (tw, _), _ = cv2.getTextSize(test, cv2.FONT_HERSHEY_SIMPLEX, 0.33, 1)
                if tw > pw - pad*2:
                    put_text_shadow(frame, line, px+pad, y, 0.33, (140,155,165), 1)
                    y += 14
                    line = word
                    if y > h - 80:
                        break
                else:
                    line = test
            if line and y <= h - 80:
                put_text_shadow(frame, line, px+pad, y, 0.33, (140,155,165), 1)
                y += 14

            # Alert
            if r.get("critical") and r.get("alert_message"):
                alert_y = h - 72
                overlay = frame.copy()
                cv2.rectangle(overlay, (px+pad-4, alert_y), (px+pw-pad+4, h-42), (20,20,160), -1)
                cv2.addWeighted(overlay, 0.88, frame, 0.12, 0, frame)
                cv2.rectangle(frame, (px+pad-4, alert_y), (px+pw-pad+4, h-42), (60,60,220), 1)
                msg = r.get("alert_message", "")
                put_text_shadow(frame, msg[:36], px+pad, alert_y+14, 0.35, (255,255,255), 1)
                if len(msg) > 36:
                    put_text_shadow(frame, msg[36:70], px+pad, alert_y+28, 0.35, (255,255,255), 1)
        else:
            desc = r.get("description", "No sign detected")
            put_text_shadow(frame, "NO SIGN DETECTED", px+pad, y, 0.42, (100,120,130), 1)
            y += 18
            put_text_shadow(frame, desc[:36], px+pad, y, 0.32, (100,120,130), 1)

    def _draw_controls(self, frame):
        h, w = frame.shape[:2]
        draw_panel_bg(frame, 0, h-34, w, h, 0.85)
        cv2.line(frame, (0, h-34), (w, h-34), (50,60,70), 1)
        hints = [("SPACE","Scan"), ("A",f"Auto:{'ON' if self.auto_mode else 'OFF'}"),
                 ("S","Save"), ("C","Clear"), ("Q","Quit")]
        x = 10
        for key, lbl in hints:
            (kw,_),_ = cv2.getTextSize(key, cv2.FONT_HERSHEY_SIMPLEX, 0.33, 1)
            cv2.rectangle(frame, (x-2, h-28), (x+kw+6, h-12), (45,55,65), -1)
            put_text_shadow(frame, key, x+2, h-15, 0.33, (220,225,230), 1)
            x += kw + 12
            (lw,_),_ = cv2.getTextSize(lbl, cv2.FONT_HERSHEY_SIMPLEX, 0.33, 1)
            put_text_shadow(frame, lbl, x, h-15, 0.33, (100,120,130), 1)
            x += lw + 18

    def run(self):
        if self.model is None:
            return

        cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            print("[ERROR] Cannot open camera.")
            return

        cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)

        fps_t = time.time()
        fps_count = 0
        fps = 0.0

        print("[RUN] Camera live — hold a sign to the camera and press SPACE")
        print()

        while self.running:
            ret, frame = cap.read()
            if not ret:
                break

            fps_count += 1
            if time.time() - fps_t >= 0.5:
                fps = fps_count / (time.time() - fps_t)
                fps_count = 0
                fps_t = time.time()

            display = frame.copy()

            # ── Stage 1: Region detection + ML ────────────
            raw_regions = self.region_detector.find_regions(frame)
            annotated = []
            for (x, y, w, h, color_name) in raw_regions:
                roi = frame[y:y+h, x:x+w]
                label, conf, scores = self._predict_region(roi)
                annotated.append((x, y, w, h, color_name, label, conf, scores))

            self.last_ml_detections = annotated
            self._draw_ml_boxes(display, annotated)

            # ── Stage 2: Auto scan ─────────────────────────
            if self.auto_mode and not self.scanning:
                if time.time() - self.last_auto >= self.auto_interval:
                    self.last_auto = time.time()
                    self._ai_analyze(frame.copy())

            # ── Draw UI ────────────────────────────────────
            if self.scanning:
                draw_scan_corners(display)
            self._draw_header(display, fps)
            self._draw_ai_panel(display)
            self._draw_controls(display)

            cv2.imshow("Traffic Sign Recognition System", display)

            # ── Keys ──────────────────────────────────────
            key = cv2.waitKey(1) & 0xFF
            if key in [ord('q'), 27]:
                break
            elif key == ord(' '):
                self._ai_analyze(frame.copy())
            elif key == ord('a'):
                self.auto_mode = not self.auto_mode
                print(f"[AUTO] {'ON' if self.auto_mode else 'OFF'}")
                self.last_auto = 0
            elif key == ord('c'):
                self.ai_result = None
            elif key == ord('s'):
                os.makedirs("screenshots", exist_ok=True)
                ts = time.strftime("%Y%m%d_%H%M%S")
                fname = f"screenshots/det_{ts}.jpg"
                cv2.imwrite(fname, display)
                print(f"[SAVE] {fname}")

        cap.release()
        cv2.destroyAllWindows()
        print(f"\n[DONE] Session ended — {self.total} total detections")
