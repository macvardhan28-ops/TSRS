"""
============================================================
  main.py — Entry Point

  USAGE:
    Step 1 — Generate training dataset:
      python training/generate_dataset.py

    Step 2 — Train the model:
      python training/train_model.py

    Step 3 — Run the detector:
      python main.py

  CONTROLS:
    SPACE  — Capture & analyze (Claude AI or ML fallback)
    A      — Toggle auto-detect every 5 seconds
    S      — Save screenshot
    C      — Clear current AI result
    Q/ESC  — Quit
============================================================
"""

import sys, os

# ── Make sure Python can find all project modules ──────────
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)
os.chdir(BASE_DIR)   # Always run from the project root folder


def check_setup():
    """Check that training has been done before starting."""
    model_path = os.path.join(BASE_DIR, "models", "sign_model.pkl")
    dataset_path = os.path.join(BASE_DIR, "dataset", "raw")

    if not os.path.exists(model_path):
        print()
        print("=" * 62)
        print("  SETUP REQUIRED — Model not trained yet")
        print("=" * 62)
        print()
        print("  Open a terminal (Command Prompt) and run these commands")
        print("  in order:")
        print()
        print(f"  1)  cd \"{BASE_DIR}\"")
        print()
        print("  2)  python training/generate_dataset.py")
        print("      (generates 6,000 training images — takes ~1 min)")
        print()
        print("  3)  python training/train_model.py")
        print("      (trains the ML model — takes ~2-3 min)")
        print()
        print("  4)  python main.py")
        print("      (then run this again)")
        print()
        print("=" * 62)

        # Offer to auto-run training right now
        choice = input("\n  Run training now automatically? (y/n): ").strip().lower()
        if choice == 'y':
            print()
            print("  [STEP 1] Generating dataset...")
            import subprocess
            result = subprocess.run(
                [sys.executable, os.path.join(BASE_DIR, "training", "generate_dataset.py")],
                cwd=BASE_DIR
            )
            if result.returncode != 0:
                print("\n  [ERROR] Dataset generation failed. See error above.")
                return False

            print()
            print("  [STEP 2] Training model...")
            result = subprocess.run(
                [sys.executable, os.path.join(BASE_DIR, "training", "train_model.py")],
                cwd=BASE_DIR
            )
            if result.returncode != 0:
                print("\n  [ERROR] Training failed. See error above.")
                return False

            print("\n  [OK] Training complete! Starting detector...\n")
            return True
        else:
            print("\n  Run the 3 commands above, then restart main.py\n")
            return False

    return True


from detector import TrafficSignDetector

def main():
    print("=" * 62)
    print("   TRAFFIC SIGN RECOGNITION SYSTEM  v2.0")
    print("   20 Sign Classes | ML + AI Pipeline")
    print("=" * 62)
    print()

    if not check_setup():
        return

    print("  Controls:")
    print("    SPACE  — Analyze current frame")
    print("    A      — Toggle auto-detect every 5 seconds")
    print("    S      — Save screenshot")
    print("    C      — Clear result panel")
    print("    Q/ESC  — Quit")
    print()

    app = TrafficSignDetector()
    app.run()

if __name__ == "__main__":
    main()
